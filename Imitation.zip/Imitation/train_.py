from torchvision import transforms
from torch.autograd import Variable
import visdom
from torch.utils.data import DataLoader
from torchvision.utils import save_image
from loss import *
from dataloader import*
import random
from network import Encoder, ShareLayer, Generator, Discriminator
import json
import argparse
from torchnet import meter
from torchvision.transforms import transforms as T
import time


parser = argparse.ArgumentParser()
parser.add_argument('--epoch', type=int, default=0, help='starting epoch')
parser.add_argument('--n_epochs', type=int, default=400, help='number of epochs of training')
parser.add_argument('--batchSize', type=int, default=1, help='size of the batches')
parser.add_argument('--dataroot_sketch', type=str, default='E:/DataBase/test/',
                    help='root directory of the dataset')
parser.add_argument('--dataroot_gray', type=str, default='E:/DataBase/gray/',
                    help='root directory of the dataset')
parser.add_argument('--dataroot_color', type=str, default='E:/DataBase/color_png/',
                    help='root directory of the dataset')

parser.add_argument('--dataroot_sketch_val', type=str, default='E:/DataBase/S/',
                    help='root directory of the dataset')
parser.add_argument('--dataroot_gray_val', type=str, default='E:/DataBase/gray_224/',
                    help='root directory of the dataset')
parser.add_argument('--dataroot_color_val', type=str, default='E:/DataBase/color_png/',
                    help='root directory of the dataset')

parser.add_argument('--lr', type=float, default=0.0002, help='initial learning rate')
parser.add_argument('--decay_epoch', type=int, default=100,
                    help='epoch to start linearly decaying the learning rate to 0')
parser.add_argument('--size', type=int, default=256, help='size of the data crop (squared assumed)')
parser.add_argument('--input_nc', type=int, default=1, help='number of channels of input data')
parser.add_argument('--output_nc', type=int, default=1, help='number of channels of output data')
parser.add_argument('--cuda', default=True, help='use GPU computation')
parser.add_argument('--n_cpu', type=int, default=0, help='number of cpu threads to use during batch generation')
opt = parser.parse_args()
print(opt)


# data prepare
train_loader = DataLoader(myDataset(root_gray=opt.dataroot_gray, root_sketch=opt.dataroot_sketch), batch_size=opt.batchSize,
                          shuffle=True, drop_last=True)
val_loader = DataLoader(myDataset(root_gray=opt.dataroot_gray, root_sketch=opt.dataroot_sketch), batch_size=opt.batchSize,
                          shuffle=True, drop_last=True)

# Networks
device = torch.device('cpu')

# EfficientUnet test
encoder = Encoder().to(device)
res = ShareLayer().to(device)
gen = Generator().to(device)

AE_encoder = Encoder().to(device)
AE_res = ShareLayer().to(device)
AE_encoder.eval()
AE_res.eval()


dis = Discriminator().to(device)

print(gen)
# Loading checkpoints
print('Loading checkpoingts')
# G_S2Gray = nn.DataParallel(G_S2Gray,device_ids=[0, 1])
# G_G2Color = nn.DataParallel(G_G2Color,device_ids=[0, 1])
# Sketch_encoder = nn.DataParallel(Sketch_encoder,device_ids=[0, 1])
# Sketch_share_layer = nn.DataParallel(Sketch_share_layer,device_ids=[0, 1])
# D = nn.DataParallel(D,device_ids=[0, 1])


# Lossess
criterion_perpix = torch.nn.L1Loss()
criterion_GAN = torch.nn.BCELoss()
criterion_G = nn.BCELoss()
criterion_perceptual = PerceptualLoss().to(device)


# Optimizers
gen_p = torch.optim.Adam(gen.parameters(), lr=0.0001, betas=(0.5, 0.999))
res_p = torch.optim.Adam(res.parameters(), lr=0.0001, betas=(0.5, 0.999))
encoder_p = torch.optim.Adam(encoder.parameters(), lr=0.0001, betas=(0.5, 0.999))

dis_p = torch.optim.Adam(dis.parameters(), lr=0.0001, betas=(0.5, 0.999))

T = False
time = 0

# Visualize
vis = visdom.Visdom()
vis.line([0.],[0.],win='train_loss',opts=dict(title ='train_loss_G'))
vis.line([0.],[0.],win='dis_loss',opts=dict(title ='dis_loss'))

vis.line([0.],[0.],win='val_loss',opts=dict(title ='val_loss'))

gen_dict = dict()
dis_dict = dict()
def getdloss(sketch,gray,total_iter,epoch,i):
    with torch.no_grad():
        # fake
        fake_color_score = dis(torch.cat((sketch, gen(res(encoder(sketch)))), 1))

        # real
        real_score = dis(torch.cat((sketch, gray), 1))

        fake_label = torch.zeros_like(real_score)
        real_label = torch.ones_like(real_score)
        d_loss1 = criterion_GAN(fake_color_score, fake_label)
        d_loss2 = criterion_GAN(real_score, real_label)
        d_loss_g = (d_loss1 + d_loss2) * 0.5

        return d_loss_g
def train_dis(sketch,gray,total_iter,epoch,i):
    gen.eval()
    res.eval()
    encoder.eval()

    dis.train()

    # fake
    fake_color_score = dis(torch.cat((sketch, gen(res(encoder(sketch)))), 1))

    # real
    real_score = dis(torch.cat((sketch, gray), 1))

    fake_label = torch.zeros_like(real_score)
    real_label = torch.ones_like(real_score)
    d_loss1 = criterion_GAN(fake_color_score, fake_label)
    d_loss2 = criterion_GAN(real_score, real_label)
    d_loss_g = (d_loss1 + d_loss2) * 0.5
    dis_p.zero_grad()
    d_loss_g.backward()
    dis_p.step()

    # add loss
    vis.line([d_loss_g.item()], [total_iter], win='dis_loss', update='append')
    dis_dict[total_iter] = d_loss_g.item()

    return d_loss_g

def train_gen(sketch,gray,total_iter,epoch,i):
    # train G
    gen.train()
    res.train()
    encoder.train()

    dis.eval()

    fake_feature = res(encoder(sketch))
    real_feature = AE_res(AE_encoder(gray))

    fake_color = gen(fake_feature)

    fake_scores = dis(torch.cat((sketch, fake_color), 1))

    # per-pix loss
    perpix = criterion_perpix(fake_color, gray)

    # GAN
    label = torch.zeros_like(fake_scores)
    Gan = -criterion_G(fake_scores, label)

    # perceptual loss
    perceptual = criterion_perceptual(fake_color, gray)

    #feature loss
    feature_loss = criterion_perpix(fake_feature,real_feature)

    loss_G = perpix * 10 + Gan * 0.1 + perceptual * 0.1 + feature_loss

    # back
    encoder_p.zero_grad()
    res_p.zero_grad()
    gen_p.zero_grad()

    loss_G.backward()

    encoder_p.step()
    res_p.step()
    gen_p.step()

    # add loss
    vis.line([loss_G.item()], [total_iter], win='train_loss', update='append')
    gen_dict[total_iter] = loss_G.item()

    if total_iter % 50 == 0:
        save_image(sketch[:4].cpu(), './output/sketch/sketch-{}-{}.png'.format(epoch + 1, i), nrow=4)
        save_image(fake_color[:4].cpu(), f'./output/fake_color/fake_color-{epoch + 1}-{i}.png', nrow=4)

    return loss_G
# Training
def train():
    total_iter = 0
    global T,time
    ###### Training ######
    best_loss_G = float('inf')
    for epoch in range(opt.epoch, opt.n_epochs):
        for i, img in enumerate(train_loader):
            # Set model input
            sketch, gray = img
            gray = Variable(gray).to(device)
            sketch = Variable(sketch).to(device)


            #train dis_g
            if total_iter% 5== 0 and T == False:
                print('trian D')
                d_loss_g = train_dis(sketch,gray,total_iter,epoch,i)

            print('trian G')
            loss_G = train_gen(sketch, gray, total_iter,epoch,i)

            if total_iter%10 == 0:
                loss_d_g = getdloss(sketch, gray, total_iter,epoch,i)

            if (i + 1) % 1== 0:
                loss_g = loss_G.item()
                loss_d_g = d_loss_g.item()
                loss_d_s = 0
                print('Epoch [{}/{}], loss_G: {:.6f}, loss_D_g: {:.6f}, loss_D_s: {:.6f} '
                      .format(epoch, opt.n_epochs, loss_g, loss_d_g, loss_d_s))

            total_iter = total_iter + 1

            if loss_d_g <0.45 and T==False:
                T = True
                time=0
                print('T set True-----------------------------------')
            if loss_d_g > 0.45:
                T = False

            if T==True:
                time = time+1
                if time ==30:
                    T = False
                    time = 0
                    print("T set False")

            if total_iter%10==0:
                filename1 = 'train_loss.json'
                with open(filename1, 'w') as file_obj:
                    json.dump(gen_dict, file_obj)
                filename2 = 'dis_loss_s.json'
                with open(filename2, 'w') as file_obj:
                    json.dump(dis_dict, file_obj)
            # Save models checkpoints
        val_loss = val(epoch, total_iter)
        print(f'Now best loss: {best_loss_G}')
        if val_loss < best_loss_G:
            best_loss_G = val_loss
            torch.save(encoder.state_dict(), 'checkpoints/Encoder/encoder%i_best.pth' % epoch)
            torch.save(res.state_dict(), 'checkpoints/Decoder/res%i_best.pth' % epoch)
            torch.save(gen.state_dict(), 'checkpoints/Decoder/gen%i_best.pth' % epoch)
        if epoch % 5 == 0:
            torch.save(encoder.state_dict(), 'checkpoints/Encoder/Encoder%i_fix.pth' % epoch)
            torch.save(res.state_dict(), 'checkpoints/Decoder/res%i_fix.pth' % epoch)
            torch.save(gen.state_dict(), 'checkpoints/Decoder/gen%i_fix.pth' % epoch)

def val(epoch,total_iter):
    gen.eval()
    res.eval()
    encoder.eval()
    val_loss_mete = meter.AverageValueMeter()
    with torch.no_grad():
        for iter, img in enumerate(val_loader):
            sketch, gray = img
            gray = Variable(gray).to(device)
            sketch = Variable(sketch).to(device)

            fake_feature = res(encoder(sketch))
            real_feature = AE_res(AE_encoder(gray))

            fake_color = gen(fake_feature)

            fake_scores = dis(torch.cat((sketch, fake_color), 1))

            # per-pix loss
            perpix = criterion_perpix(fake_color, gray)

            # GAN
            label = torch.zeros_like(fake_scores)
            Gan = -criterion_G(fake_scores, label)

            # perceptual loss
            perceptual = criterion_perceptual(fake_color, gray)

            # feature loss
            feature_loss = criterion_perpix(fake_feature, real_feature)

            loss_G = perpix * 10 + Gan * 0.1 + perceptual * 0.1 + feature_loss

            val_loss_mete.add(loss_G.item())

            #保存图片
            if iter % 5 == 0:
                save_image(fake_color[:4].cpu(), f'./output/val_fake_color/val_fake_color-{epoch + 1}-{iter}.png', nrow=4)

        vis.line([val_loss_mete.value()[0]], [total_iter], win='val_loss', update='append')
        print(f'Epoch: {epoch},Val loss: {val_loss_mete.value()[0]}')

    gen.train()
    res.train()
    encoder.train()

    return val_loss_mete.value()[0]

train()
