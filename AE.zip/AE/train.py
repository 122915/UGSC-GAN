from torchvision import transforms
from torch.autograd import Variable
import visdom
from torch.utils.data import DataLoader
from torchvision.utils import save_image
from loss import *
from datasets import*
import random
import json
import argparse
from network import*
from torchvision.transforms import transforms as T
from torchnet import meter
import time


parser = argparse.ArgumentParser()
parser.add_argument('--epoch', type=int, default=0, help='starting epoch')
parser.add_argument('--n_epochs', type=int, default=400, help='number of epochs of training')
parser.add_argument('--batchSize', type=int, default=1, help='size of the batches')
parser.add_argument('--dataroot_sketch', type=str, default='E:/DataBase/two_part/sketch(2)/',
                    help='root directory of the dataset')

parser.add_argument('--dataroot_gray', type=str, default='D:/Data/test/',
                    help='root directory of the dataset')
parser.add_argument('--dataroot_gray_val', type=str, default='D:/Data/test/',
                    help='root directory of the dataset')

parser.add_argument('--dataroot_color', type=str, default='E:/DataBase/color_png/',
                    help='root directory of the dataset')

parser.add_argument('--lr', type=float, default=0.0002, help='initial learning rate')
parser.add_argument('--decay_epoch', type=int, default=100,
                    help='epoch to start linearly decaying the learning rate to 0')
parser.add_argument('--size', type=int, default=256, help='size of the data crop (squared assumed)')
parser.add_argument('--input_nc', type=int, default=1, help='number of channels of input data')
parser.add_argument('--output_nc', type=int, default=1, help='number of channels of output data')
parser.add_argument('--cuda', default=True, help='use GPU computation')
parser.add_argument('--n_cpu', type=int, default=0, help='number of cpu threads to use during batch generation')
opt = parser.parse_args()
print(opt)


# data prepare
train_loader = DataLoader(myDataset(root_gray=opt.dataroot_gray), batch_size=opt.batchSize,
                          shuffle=True, drop_last=True)
val_loader = DataLoader(myDataset(root_gray=opt.dataroot_gray_val), batch_size=opt.batchSize,
                          shuffle=True, drop_last=True)

# Networks
device = torch.device('cpu')

encoder = Encoder().to(device)
res = ShareLayer().to(device)
decoder = Generator().to(device)

print('Loading checkpoingts')
# G_S2Gray = nn.DataParallel(G_S2Gray,device_ids=[0, 1])
# G_G2Color = nn.DataParallel(G_G2Color,device_ids=[0, 1])
# Sketch_encoder = nn.DataParallel(Sketch_encoder,device_ids=[0, 1])
# Sketch_share_layer = nn.DataParallel(Sketch_share_layer,device_ids=[0, 1])
# D = nn.DataParallel(D,device_ids=[0, 1])


# Lossess
criterion_perpix = torch.nn.L1Loss()


# Optimizers
encoder_p = torch.optim.Adam(encoder.parameters(), lr=0.0001, betas=(0.5, 0.999))
res_p = torch.optim.Adam(res.parameters(), lr=0.0001, betas=(0.5, 0.999))
decoder_p = torch.optim.Adam(decoder.parameters(), lr=0.0001, betas=(0.5, 0.999))



# Visualize
vis = visdom.Visdom()
vis.line([0.],[0.],win='train_loss',opts=dict(title ='train_loss_G'))
vis.line([0.],[0.],win='val_loss',opts=dict(title ='val_loss'))

gen_dict = dict()

# Training
def train():
    total_iter = 0
    ###### Training ######
    best_loss_G = float('inf')
    for epoch in range(opt.epoch, opt.n_epochs):
        for i, img in enumerate(train_loader):
            # Set model input
            gray = img
            gray = Variable(gray).to(device)

            fake = decoder(res(encoder(gray)))

            #per-pix loss
            perpix = criterion_perpix(fake,gray)

            #back
            encoder_p.zero_grad()
            res.zero_grad()
            decoder_p.zero_grad()

            perpix.backward()

            encoder_p.step()
            res_p.step()
            decoder_p.step()

            #add loss
            vis.line([perpix.item()], [total_iter], win='train_loss', update='append')
            gen_dict[total_iter]=perpix.item()

            if total_iter % 50 == 0:
                save_image(fake[:4].cpu(), f'./output/fake_color/fake_color-{epoch + 1}-{i}.png', nrow=4)
                save_image(gray[:4].cpu(), './output/real_color/real_color-{}-{}.png'.format(epoch + 1, i), nrow=4)

            if (i + 1) % 1== 0:
                loss_g = perpix.item()
                loss_d_g = 0
                loss_d_s = 0
                print('Epoch [{}/{}], loss: {:.6f}, loss_D_g: {:.6f}, loss_D_s: {:.6f} '
                      .format(epoch, opt.n_epochs, loss_g, loss_d_g, loss_d_s))

            total_iter = total_iter + 1
            if total_iter%5==0:
                filename1 = 'train_loss.json'
                with open(filename1, 'w') as file_obj:
                    json.dump(gen_dict, file_obj)

                vis.save(['main'])
            # Save models checkpoints
        #验证
        val_loss = val(epoch,total_iter)
        print(f'Now best loss: {best_loss_G}')
        if val_loss <best_loss_G:
            best_loss_G = val_loss
            torch.save(encoder.state_dict(), 'checkpoints/Encoder/encoder%i_best.pth' % epoch)
            torch.save(res.state_dict(), 'checkpoints/Res/res%i_best.pth' % epoch)
            torch.save(decoder.state_dict(), 'checkpoints/Decoder/decoder%i_best.pth' % epoch)

        if epoch % 5 == 0:
            torch.save(encoder.state_dict(), 'checkpoints/Encoder/encoder%i_fix.pth' % epoch)
            torch.save(res.state_dict(), 'checkpoints/Res/res%i_fix.pth' % epoch)
            torch.save(decoder.state_dict(), 'checkpoints/Decoder/decoder%i_fix.pth' % epoch)

def val(epoch,total_iter):
    encoder.eval()
    res.eval()
    decoder.eval()
    val_loss_mete = meter.AverageValueMeter()
    with torch.no_grad():
        for iter, img in enumerate(val_loader):
            gray = img
            gray = Variable(gray).to(device)

            fake = decoder((encoder(gray)))

            perpix = criterion_perpix(fake,gray)

            val_loss_mete.add(perpix.item())

            #保存图片
            if iter % 5 == 0:
                save_image(fake[:4].cpu(), f'./output/val_fake_color/val_fake_color-{epoch + 1}-{iter}.png', nrow=4)

        vis.line([val_loss_mete.value()[0]], [total_iter], win='val_loss', update='append')
        print(f'Epoch: {epoch},Val loss: {val_loss_mete.value()[0]}')

    encoder.train()
    res.train()
    decoder.train()

    return val_loss_mete.value()[0]


train()
