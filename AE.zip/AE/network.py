import torch
import torch.nn as nn
import torch.nn.functional as F

#网络参数初始化
def initialize_weights(net):
    for m in net.modules():
        if isinstance(m, nn.Conv2d):
            m.weight.data.normal_(0, 0.02)
            m.bias.data.zero_()
        elif isinstance(m, nn.ConvTranspose2d):
            m.weight.data.normal_(0, 0.02)
            m.bias.data.zero_()
        elif isinstance(m, nn.Linear):
            m.weight.data.normal_(0, 0.02)
            m.bias.data.zero_()
        elif isinstance(m, nn.BatchNorm2d):
            m.weight.data.normal_(0, 0.02)
            m.bias.data.zero_()

class ResnetBlock(nn.Module):
    def __init__(self, dim):
        super(ResnetBlock, self).__init__()
        self.conv_block = nn.Sequential(
            nn.Conv2d(in_channels=dim, out_channels=dim, kernel_size=3,stride=1,padding=1),
            nn.BatchNorm2d(dim),
            nn.ReLU(True),

            nn.Conv2d(in_channels=dim, out_channels=dim, kernel_size=3, stride=1,padding=1),
            nn.BatchNorm2d(dim),
            nn.ReLU(True),
        )
        #初始化参数
        initialize_weights(self)

    def forward(self, x):
        out = x + self.conv_block(x)

        # Remove ReLU at the end of the residual block
        # http://torch.ch/blog/2016/02/04/resnets.html

        return out


class Generator(nn.Module):
    def __init__(self):
        super(Generator, self).__init__()

        self.deconv1 = nn.Sequential(
            nn.ConvTranspose2d(512, 256, kernel_size=2, stride=2),
            nn.BatchNorm2d(256),
            nn.ReLU(True),
            nn.Conv2d(256, 256, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(True),
            nn.Conv2d(256, 256, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(True)
        )

        self.deconv2 = nn.Sequential(
            nn.ConvTranspose2d(256, 128, kernel_size=2, stride=2),
            nn.BatchNorm2d(128),
            nn.ReLU(True),
            nn.Conv2d(128, 128, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(True),
            nn.Conv2d(128, 128, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(True)
        )

        self.deconv3 = nn.Sequential(
            nn.ConvTranspose2d(128, 64, kernel_size=2, stride=2),
            # 63 128
            nn.BatchNorm2d(64),
            nn.ReLU(True),
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(True),
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(True)
        )
        self.deconv4 = nn.Sequential(
            nn.ConvTranspose2d(64, 1, kernel_size=2, stride=2),
            # 63 128
            nn.BatchNorm2d(1),
            nn.ReLU(True),
            nn.Conv2d(1, 1, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(1),
            nn.ReLU(True),
            nn.Conv2d(1, 1, kernel_size=3, stride=1, padding=1),
            #nn.BatchNorm2d(1),
            #nn.ReLU(True)
        )
        #初始化参数
        initialize_weights(self)

    def forward(self, x):
        dx1 = self.deconv1(x) #out 256 32*32
        dx2 = self.deconv2(dx1) #out 128 64*64
        dx3 = self.deconv3(dx2) #out 64 128*128
        dx4 = self.deconv4(dx3) #out 1  256*256
        return F.tanh(dx4)

class Encoder(nn.Module):
    def __init__(self):
        super(Encoder, self).__init__()
        self.conv1 = nn.Sequential(
            nn.Conv2d(in_channels=1, out_channels=64, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(True)
        )

        self.conv2 = nn.Sequential(
            nn.Conv2d(in_channels=64, out_channels=128, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(True)
        )

        self.conv3 = nn.Sequential(
            nn.Conv2d(in_channels=128, out_channels=256, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(True),
        )
        self.conv4 = nn.Sequential(
            nn.Conv2d(in_channels=256, out_channels=512, kernel_size=3, stride=2, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(True),
        )
        # 初始化参数
        initialize_weights(self)
    def forward(self, x):
        x = self.conv1(x) #out 64 128*128
        x = self.conv2(x) #out 128 64*64
        x = self.conv3(x) #out 256 32*32
        x = self.conv4(x) #out 512 16*16
        return x

class ShareLayer(nn.Module):
    def __init__(self):
        super(ShareLayer, self).__init__()

        blocks = []
        for _ in range(8):
            block = ResnetBlock(512)
            blocks.append(block)

        self.middle = nn.Sequential(*blocks)
        # 初始化参数
        initialize_weights(self)
    def forward(self,x):
        x = self.middle(x)

        return x


class Discriminator(nn.Module):

    def __init__(self):
        super(Discriminator,self).__init__()

        self.conv1 = nn.Sequential (
            nn.Conv2d(in_channels=2, out_channels=64, kernel_size=7,stride=2, padding=1),  #126 64
            nn.LeakyReLU(0.2, True)
        )

        self.conv2 =nn.Sequential (
            nn.Conv2d(in_channels=64, out_channels=128, kernel_size=4, stride=2, padding=1),  # 63 128
            nn.BatchNorm2d(128),
            nn.LeakyReLU(0.2, True)
        )

        self.conv3 = nn.Sequential(
            nn.Conv2d(in_channels=128, out_channels=256, kernel_size=4, stride=2, padding=1),  # 31 256
            nn.BatchNorm2d(256),
            nn.LeakyReLU(0.2, True)
        )

        self.conv4 = nn.Sequential(
            nn.Conv2d(in_channels=256, out_channels=512, kernel_size=4, stride=2, padding=1),# 15 512
            nn.BatchNorm2d(512),
            nn.LeakyReLU(0.2, True)
        )

        self.conv5 = nn.Sequential(
            nn.Conv2d(in_channels=512, out_channels=1, kernel_size=1, stride=1, padding=0),  # 15 512
            nn.BatchNorm2d(1),
            nn.LeakyReLU(0.2, True)
        )
        #初始化参数
        initialize_weights(self)

    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.conv4(x)
        x = self.conv5(x)
        return torch.sigmoid(x)


if __name__ == "__main__":
    print("Efficient B0 Summary")
    net = Generator()
    from torchsummary import summary

    summary(net, (512, 16, 16))