import torch.utils.data
from torchvision.datasets import DatasetFolder
from torch.utils.data.sampler import Sampler
from torchvision.transforms import Scale, CenterCrop
from torch.utils import data
from PIL import Image
import numpy as np
import os
from torchvision import transforms
from PIL import ImageFilter
from PIL import ImageChops
import cv2
from random import randint
import numpy as np

canny_transform= transforms.Compose([
        # transforms.Resize((224,224)),
        # transforms.RandomHorizontalFlip(0.5),
        # transforms.RandomCrop((256,256)),
        transforms.ToTensor(),
        # transforms.Normalize((0.5,),(0.5,))
    ])

img_transform = transforms.Compose([
        # transforms.Resize((256,256)),
        # transforms.RandomHorizontalFlip(0.5),
        # transforms.RandomCrop((256,256)),
        transforms.ToTensor(),
        # transforms.Normalize((0.5,0.5,0.5),(0.5,0.5,0.5))
])

img_transform_fea = transforms.Compose([
        transforms.Resize((512,512)),
        # transforms.RandomHorizontalFlip(0.5),
        # transforms.RandomCrop((512,512)),
        transforms.ToTensor(),
        # transforms.Normalize((0.5,),(0.5,))
])

class myDataset(data.Dataset):
    '''
    root:图像存放地址根路径
    augment:是否需要图像增强
    '''
    def __init__(self,root_gray):
        #所有图片的绝对路径
        self.img_name = os.listdir(root_gray)

        self.root_gray = root_gray

        if len(self.img_name) == 0:
            raise (RuntimeError("Found 0 images in folders."))

    def __getitem__(self, index):
        # 自己的理解 取出第index个图片的路径
        img_name = self.img_name[index]
        gray_img_path = os.path.join(self.root_gray, img_name)

        #gray
        gray = Image.open(gray_img_path)
        gray = img_transform(gray)

        return gray

    def __len__(self):
        return len(self.img_name)
